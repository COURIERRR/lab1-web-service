/**
 * <b>A web service which performs GetIpAddress Lookups.</b>
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://lavasoft.com/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package kz.iitu.soap.ws1.client.generated;
